package com.l2plus.controller;

import static com.l2plus.data.ExampleData.CREATE_EVENT;
import static com.l2plus.data.ExampleData.UPDATE_EVENT;

import java.util.List;
import java.util.Optional;

import com.l2plus.Event;
import com.l2plus.EventServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/event")
@RequiredArgsConstructor
public class EventServiceController {

    private final EventServiceImpl eventService;

    @PostMapping
    @Operation(
        summary = "Create an event",
        responses = {
            @ApiResponse(
                responseCode = "200",
                description = "Event has been created successfully",
                content = @Content(
                    schema = @Schema(implementation = Event.class),
                    examples = {
                        @ExampleObject(
                            name = "Event creation example",
                            value = CREATE_EVENT
                        )
                    })
            )
        })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
        content = @Content(
            examples = {
                @ExampleObject(
                    name = "Event creation example",
                    value = CREATE_EVENT
                )
            })
        )
    public ResponseEntity<Event> createEvent(@RequestBody Event event) {
        return ResponseEntity.ok(eventService.createEvent(event));
    }

    @PatchMapping
    @Operation(summary = "Update an event")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
        content = @Content(
            examples = {
                @ExampleObject(
                    name = "Event creation example",
                    value = UPDATE_EVENT
                )
            })
    )
    public ResponseEntity<Event> updateEvent(@RequestBody Event event) {
        return ResponseEntity.ok(eventService.updateEvent(event));
    }

    @GetMapping(params = {"id"})
    @Operation(summary = "Get an event by id")
    public ResponseEntity<Optional<Event>> getEvent(@RequestParam int id) {
        return ResponseEntity.ok(eventService.getEvent(id));
    }

    @GetMapping(path = "/all")
    @Operation(summary = "Get all events")
    public ResponseEntity<List<Event>> getEvents() {
        return ResponseEntity.ok(eventService.getAllEvents());
    }

    @GetMapping(path = "/title")
    @Operation(summary = "Get events by title")
    public ResponseEntity<List<Event>> getEventByTitle(@RequestParam(value = "title") String title) {
        return ResponseEntity.ok(eventService.getAllEventsByTitle(title));
    }

    @DeleteMapping(params = {"id"})
    @Operation(summary = "Delete an event")
    public void deleteEvent(@RequestParam(name = "id") int id) {
        eventService.deleteEvent(id);
    }
}
