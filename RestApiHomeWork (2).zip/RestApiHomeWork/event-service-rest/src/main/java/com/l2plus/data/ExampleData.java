package com.l2plus.data;

public class ExampleData {
    public static final String CREATE_EVENT = "{\n" +
        "  \"id\": 1,\n" +
        "  \"title\": \"Event Title\",\n" +
        "  \"place\": \"100\",\n" +
        "  \"speaker\": \"Speaker Name\",\n" +
        "  \"eventType\": \"Type of event\",\n" +
        "  \"dateTime\": \"2000.12.12.\"\n" +
        "}";

    public static final String UPDATE_EVENT = "{\n" +
        "  \"id\": 1,\n" +
        "  \"title\": \"Updated Event Title\",\n" +
        "  \"place\": \"100\",\n" +
        "  \"speaker\": \"Updated Speaker Name\",\n" +
        "  \"eventType\": \"Updated Type of event\",\n" +
        "  \"dateTime\": \"2000.12.12.\"\n" +
        "}";
}
