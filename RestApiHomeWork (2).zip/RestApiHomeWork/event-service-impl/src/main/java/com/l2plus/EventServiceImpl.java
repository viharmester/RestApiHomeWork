package com.l2plus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class EventServiceImpl implements EventService {
    private ArrayList<Event> localDB = new ArrayList<>();

    @Override
    public Event createEvent(Event event) {
        localDB.add(event);
        return event;
    }

    @Override
    public Event updateEvent(Event event) {
        var first = localDB.stream()
            .filter(ev -> ev.getId() == event.getId())
            .findFirst();

        if (first.isPresent()) {
            int index = localDB.indexOf(first.get());
            localDB.set(index, event);
        } else {
            localDB.add(event);
        }

        return event;
    }

    @Override
    public Optional<Event> getEvent(int id) {
        return localDB.stream()
            .filter(ev -> ev.getId() == id)
            .findFirst();
    }

    @Override
    public List<Event> getAllEvents() {
        return localDB;
    }

    @Override
    public List<Event> getAllEventsByTitle(String title) {
        return localDB.stream()
            .filter(ev -> ev.getTitle().toLowerCase().contains(title.toLowerCase()))
            .collect(Collectors.toList());
    }

    @Override
    public void deleteEvent(int id) {
        var first = localDB.stream()
            .filter(ev -> ev.getId() == id)
            .findFirst();
        first.ifPresent(event -> localDB.remove(event));
    }
}
