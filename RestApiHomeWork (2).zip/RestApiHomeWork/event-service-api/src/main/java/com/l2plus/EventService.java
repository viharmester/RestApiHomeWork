package com.l2plus;

import java.util.List;
import java.util.Optional;

public interface EventService {
    Event createEvent(Event event);

    Event updateEvent(Event event);

    Optional<Event> getEvent(int id);

    List<Event> getAllEvents();

    List<Event> getAllEventsByTitle(String title);

    void deleteEvent(int id);
}
