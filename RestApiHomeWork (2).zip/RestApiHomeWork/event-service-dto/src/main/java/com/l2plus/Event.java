package com.l2plus;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Event {
    private int id;
    private String title;
    private String place;
    private String speaker;
    private String eventType;
    private String dateTime;
}
